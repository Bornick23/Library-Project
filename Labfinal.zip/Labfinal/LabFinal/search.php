<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f9;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h2 {
            text-align: center;
            color: #007BFF;
        }
        .search-result {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }
        .search-result:last-child {
            border-bottom: none;
        }
        .search-result h3 {
            margin: 0;
            color: #555;
        }
        .search-result p {
            margin: 5px 0 0;
            color: #777;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Search Results</h2>
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "book_library";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if ($_SERVER["REQUEST_METHOD"] == "GET") {
            $search_query = $_GET['search_query'];
            $sql = "SELECT * FROM books WHERE book_title LIKE '%$search_query%' OR author LIKE '%$search_query%' OR genre LIKE '%$search_query%'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='search-result'>";
                    echo "<h3>Title: " . $row["book_title"]. "</h3>";
                    echo "<p>Author: " . $row["author"]. "</p>";
                    echo "<p>Genre: " . $row["genre"]. "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No results found</p>";
            }
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
